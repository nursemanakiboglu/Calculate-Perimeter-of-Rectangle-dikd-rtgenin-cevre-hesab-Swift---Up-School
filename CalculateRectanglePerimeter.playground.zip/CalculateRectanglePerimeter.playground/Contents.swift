import UIKit

class Program
{
    var per : Int?
    
    func rectangle (edgeA : Int, edgeB : Int)
    {
        per = 2 * (edgeA + edgeB)
        print("Perimeter: \(per!)")
    }
}

let result = Program()

result.rectangle(edgeA: 5, edgeB: 2)
